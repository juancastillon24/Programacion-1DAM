public class Recta extends Vector{
    private Vector director;
    private Punto p;


    public Recta(Punto p1, Punto p2) {
        super(p1, p2);
    }

    public Recta(Vector director, Punto p){
        super(director,p);
    }






}
